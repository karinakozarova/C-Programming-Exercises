#include <stdio.h>

int main() {
	int arr[] = {5, 4, 3, 2, 1};
	int *ptr = arr;

	printf("%d\n", 3[ptr]);
}
