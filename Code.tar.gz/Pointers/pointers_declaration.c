#include <stdio.h>

int* rotr(int *a, int *b, int *c);

int main() {
	
	int *a;
	int* b;

	int *c, d, e; // same as int* c, d, e; , but only c is a pointer!
	int *f, *g, *h; // f, g and h are all pointers



	return 0;
}
