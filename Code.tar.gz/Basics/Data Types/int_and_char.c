#include <stdio.h>

int main() {
	char ch = '*';
	printf("%d -> %c\n", ch, ch);	
	return 0;
}
