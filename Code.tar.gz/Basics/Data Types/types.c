#include <stdio.h>

int main() {

	float i = 42.42;
	int f = 2;

	float res = (double) 3.58888888889;
	short s = (int) 278999999999999123;

	printf("%f\n", res);

return 0;
}
