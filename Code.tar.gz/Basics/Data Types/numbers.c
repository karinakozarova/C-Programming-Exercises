



#include <stdio.h>

int main() {
	float res;
	int i = 2;
	int p = 3;		

	res = ((float) i) / p;
	printf("%f\n", res);
return 0;
}
