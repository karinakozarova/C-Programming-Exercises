#include <stdio.h>

int main() {

	int a = 5;
	int b = 7;
	int c = 3;

	if (a > c || b > c){
	}

	if (a > c) {}
	else if (b > c) {}

	return 0;
}
