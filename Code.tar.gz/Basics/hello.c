#include <stdio.h>


int main() {
    printf("Hello GitHub\n");
    return 0;
        
}
