#include <stdio.h>


int main() {
	int i = 5;
	
	if (i = 10) {
		printf("True\n");
	} else {
		printf("False\n");
	}

	return 0;
}
