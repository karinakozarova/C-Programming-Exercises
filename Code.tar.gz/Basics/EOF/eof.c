#include <stdio.h>

int main() {

    for(int a; scanf("%d", &a) != EOF; printf("%d\n", a))
        ;

    return 0;

}
