#include <stdio.h>

int main() {

	int i = 5;
	int p = 7;
	int n = 3;
	
	if ( (9 > 5) < 3) {
		printf("Yup");
	}
return 0;
}
