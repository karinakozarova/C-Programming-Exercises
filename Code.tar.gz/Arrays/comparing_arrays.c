#include <stdio.h>

int main() {

    int arr[50];

    //for (int i = 0; i < 10; i++) {
    //    arr[i] = 0;
    //}

    if (arr[0] > arr[1]) {
        printf("Bigger");
    } else {
        printf("Naaah!");
    }
    return 0;
}
